# Task 4 — identical visual, three hooks

Tool: built-in image_gen for the clean text-free background; native SVG typography for identical layout and exact wording across variants. Outside the removed text regions, the original image is retained.

## Background edit

Edit this exact supplied advertising poster. Output the same portrait composition. This is a PRECISE TEXT REMOVAL task, not a redesign.
Remove ONLY all existing written text: the large silver "Create your own AI series" words in the lower middle, the red "Create Now" button together with its lettering and metallic frame, and the tiny white legal disclaimer at the very bottom. Reconstruct the dark coat, skyline and wet street naturally behind these removed text elements.
Preserve every other element and detail exactly: central man's identity, face, black suit and pose; woman on the right; larger man's profile on left; helicopters and searchlight at upper right; New York skyscrapers and bridge; burning car and orange fire at bottom right; three walking silhouettes; police car and wet reflective road; dramatic navy/black cinematic color grading. No new objects, no new actors, no composition changes, no camera change, no words, no logos, no watermark anywhere.
The result is the same original picture clean of typography, ready for three deterministic advertising headline overlays. Do not add a banner or new button.

## Hook 1
Your partner sold you out.
Now you write the ending.

## Hook 2
Cinematic drama.
Created by you.

## Hook 3
She was sent to destroy him.
She fell in love instead.

## Shared CTA
Create Your AI Series
